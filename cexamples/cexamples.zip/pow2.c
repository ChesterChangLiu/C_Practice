#include<string.h>

int main(){

  char *x[10];
  strcpy( x[1],"Hello" );

}
