#include <stdio.h>
int main() {
  int userWeights[3];
  int userAge;

  userAge = 44;
  userWeights[0] = 122;
  userWeights[1] = 119;
  userWeights[2] = 117;
  userWeights[3] = 199; 
  printf("%d\n",userAge);
}
