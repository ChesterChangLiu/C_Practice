#include<string.h>

int main(){

  int *p;
  *p = 20;

}
