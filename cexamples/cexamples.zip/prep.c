#include <stdio.h>
#define THREE 3
#define SQUARE(x) x*x
int main() {
  printf("THREE times THREE is %d\n", SQUARE(THREE));
}
